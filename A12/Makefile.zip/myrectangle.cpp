#include <iostream>
using namespace std;

class MyRectangle {
public:
    MyRectangle(double length, double width);
    void print() const;

private:
    double length;
    double width;

};

MyRectangle::MyRectangle(double newLength, double newWidth) {
    length = newLength;
    width = newWidth;
}

void MyRectangle::print() const {
    cout << "length: " << length
         << "\nwidth: " << width
         << endl;
}

// For testing
int main() {
    MyRectangle rec(3.0, 5.0);
    rec.print();

    return 0;
}